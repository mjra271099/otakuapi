const axios = require("axios");
const xlsx = require("xlsx");

const BASE_URL = 'http://localhost:3000/api/anime'; // URL API

async function fetchAnimeData(id) {
    const url = `${BASE_URL}/${id}`;
    console.log(`Fetching data from: ${url}`); // Debugging log
    const response = await axios.get(url);
    return response.data; // Kembalikan data JSON
}

async function main() {
    const workbook = xlsx.readFile('complete_anime_id.xlsx');
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];

    // Ambil ID dari kolom A (dimulai dari baris ke-2)
    const animeIds = [];
    for (let row = 2; row <= sheet['!ref'].split(':')[1].replace(/[0-9]/g, ''); row++) {
        const cell = sheet[`A${row}`];
        if (cell) {
            animeIds.push(cell.v);
        }
    }

    let allAnimeData = []; // Menyimpan semua data anime

    for (const id of animeIds) {
        try {
            const data = await fetchAnimeData(id);
            if (data && data.status === "success") {
                // Ambil semua data dan tambahkan ID untuk referensi
                const animeInfo = {
                    id: id,
                    title: data.title,
                    synopsis: data.synopsis,
                    score: data.score,
                    type: data.type,
                    status: data.status,
                    total_episode: data.total_episode,
                    release_date: data.release_date,
                    studio: data.studio,
                    genres: data.genre_list.map(genre => genre.genre_name).join(", "), // Gabungkan genre
                    episodes: data.episode_list.map(episode => ({
                        title: episode.title,
                        link: episode.link,
                        uploaded_on: episode.uploaded_on
                    }))
                };

                allAnimeData.push(animeInfo);
                console.log(`Successfully fetched data for ID: ${id}`);
            } else {
                console.log(`No data found for ID: ${id}`);
            }
        } catch (error) {
            console.error(`Error fetching data for ID: ${id}, ${error.message}`);
        }
    }

    // Buat workbook dan worksheet untuk menyimpan data ke Excel
    const newWorkbook = xlsx.utils.book_new();

    // Format data untuk worksheet
    const formattedData = allAnimeData.map(anime => ({
        ID: anime.id,
        Title: anime.title,
        Synopsis: anime.synopsis,
        Score: anime.score,
        Type: anime.type,
        Status: anime.status,
        Total_Episodes: anime.total_episode,
        Release_Date: anime.release_date,
        Studio: anime.studio,
        Genres: anime.genres,
        Episodes: anime.episodes.map(ep => `${ep.title} (${ep.uploaded_on}): ${ep.link}`).join("\n") // Gabungkan episode
    }));

    const newWorksheet = xlsx.utils.json_to_sheet(formattedData);
    xlsx.utils.book_append_sheet(newWorkbook, newWorksheet, "Anime Data");

    // Simpan workbook ke file Excel
    xlsx.writeFile(newWorkbook, 'anime_data_results.xlsx');
    console.log("Semua data anime telah disimpan ke dalam anime_data_results.xlsx");
}

main().catch(console.error);
