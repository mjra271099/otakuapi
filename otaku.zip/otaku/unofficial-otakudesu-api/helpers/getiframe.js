const xlsx = require('xlsx');
const fs = require('fs');
const { get } = require('./scraper'); // Ganti 'scraper' sesuai nama file Anda

// Fungsi untuk membaca URL dari file Excel
function readUrlsFromExcel(filePath) {
  const workbook = xlsx.readFile(filePath);
  const sheetName = workbook.SheetNames[0]; // Ambil nama sheet pertama
  const sheet = workbook.Sheets[sheetName];
  const data = xlsx.utils.sheet_to_json(sheet, { header: 1 }); // Membaca semua data sebagai array

  // Ambil URL mulai dari B2 (indeks 1 pada kolom B)
  const urls = data.slice(1).map(row => row[1]).filter(url => url); // Ambil kolom B dan hapus nilai yang tidak ada
  return urls;
}

async function fetchAll(urls) {
  const results = [];
  const totalUrls = urls.length;

  for (let i = 0; i < totalUrls; i++) {
    const url = urls[i];
    const startTime = Date.now();

    try {
      const result = await get(url);
      results.push({
        title: result.title || 'No title found', // Pastikan title diambil
        iframeSources: result.iframeSources || [],
      });
    } catch (err) {
      console.error(`Error fetching ${url}:`, err);
    }

    const elapsedTime = Date.now() - startTime;
    const estimatedTime = (elapsedTime / (i + 1)) * (totalUrls - (i + 1));
    const percentage = ((i + 1) / totalUrls) * 100;

    console.log(`Progress: ${Math.round(percentage)}% (${i + 1}/${totalUrls}) - Estimated time remaining: ${formatTime(estimatedTime)}`);
  }

  return results;
}

function formatTime(milliseconds) {
  const seconds = Math.round(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
}

// Simpan hasil ke file Excel
function saveResultsToExcel(results, outputFilePath) {
  const dataToSave = results.map(result => ({
    title: result.title,
    iframeSrc: result.iframeSources.join(', '), // Menggabungkan iframe sources menjadi satu string
  }));

  const worksheet = xlsx.utils.json_to_sheet(dataToSave);
  const workbook = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(workbook, worksheet, 'Results');

  xlsx.writeFile(workbook, outputFilePath);
}

// Baca URL dari file Excel
const urls = readUrlsFromExcel('complete_anime_links.xlsx');

fetchAll(urls).then(results => {
  saveResultsToExcel(results, 'iframe.xlsx');
  console.log("Hasil telah disimpan ke dalam iframe.xlsx");
}).catch(err => {
  console.error(err);
});
