const axios = require("axios");
const fs = require("fs");
const xlsx = require("xlsx");

const BASE_URL = 'http://localhost:3000/api/complete/page';

async function fetchCompleteAnime(page) {
    const url = `${BASE_URL}/${page}`;
    const response = await axios.get(url);
    return response.data; // Kembalikan data JSON
}

async function main() {
    let completeAnimeData = []; // Menyimpan objek dengan title dan link
    let page = 1;

    while (true) {
        const data = await fetchCompleteAnime(page);

        if (data.status !== "success" || !data.animeList || data.animeList.length === 0) {
            break; // Hentikan jika status tidak sukses atau tidak ada anime
        }

        data.animeList.forEach(anime => {
            completeAnimeData.push({
                title: anime.title, // Ambil title
                link: anime.link    // Ambil link
            });
        });

        page++;
    }

    // Buat workbook dan worksheet untuk menyimpan data ke Excel
    const workbook = xlsx.utils.book_new();
    const worksheet = xlsx.utils.json_to_sheet(completeAnimeData);

    // Tambahkan worksheet ke workbook
    xlsx.utils.book_append_sheet(workbook, worksheet, "Complete Anime");

    // Simpan workbook ke file Excel
    xlsx.writeFile(workbook, 'complete_anime_links.xlsx');
    console.log("Complete Anime Links telah disimpan ke dalam complete_anime_links.xlsx");
}

main().catch(console.error);
