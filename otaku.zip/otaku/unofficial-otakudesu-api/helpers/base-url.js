module.exports = {
    baseUrl: 'https://otakudesu.cloud/',
    completeAnime:'complete-anime/',
    onGoingAnime:'ongoing-anime/',
    schedule:'jadwal-rilis/',
    genreList:'genre-list/'
};
